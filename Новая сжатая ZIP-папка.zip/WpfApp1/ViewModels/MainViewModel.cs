using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using WpfApp1.Models;

namespace WpfApp1.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        public ObservableCollection<Item> Items { get; private set; }
        public ICommand ExitCommand { get; private set; }
        public ICommand ChangeBackgroundCommand { get; private set; }
        public ICommand AddCommand { get; private set; }

        public MainViewModel()
        {
            Items = new ObservableCollection<Item>();
            ExitCommand = new RelayCommand(ExecuteExit);
            ChangeBackgroundCommand = new RelayCommand(ExecuteChangeBackground);
            AddCommand = new RelayCommand(ExecuteAdd);
        }

        private void ExecuteExit(object parameter)
        {
            System.Windows.Application.Current.Shutdown();
        }

        private void ExecuteChangeBackground(object parameter)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image Files (*.jpg; *.jpeg; *.png; *.bmp)|*.jpg; *.jpeg; *.png; *.bmp"
            };
            if (openFileDialog.ShowDialog() == true)
            {
                string imagePath = openFileDialog.FileName;
                ImageBrush imageBrush = new ImageBrush(new BitmapImage(new Uri(imagePath)));
                Application.Current.MainWindow.Background = imageBrush;
            }
        }

        private void ExecuteAdd(object parameter)
        {
            AddItemWindow addItemWindow = new AddItemWindow();
            addItemWindow.DataContext = new AddItemWindow();
            if (addItemWindow.ShowDialog() == true)
            {
                Items.Add(((AddItemWindow)addItemWindow.DataContext).GetItem());
            }
        }
    }
}