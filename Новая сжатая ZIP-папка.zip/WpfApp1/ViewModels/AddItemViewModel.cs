using System.Windows;
using System.Windows.Input;
using WpfApp1.Models;

namespace WpfApp1.ViewModels
{
    public class AddItemWindow : ViewModelBase
    {
        private string _name;
        private string _imagePath;
        private string _exePath;

        public string Name
        {
            get => _name;
            set { _name = value; OnPropertyChanged(); }
        }

        public string ImagePath
        {
            get => _imagePath;
            set { _imagePath = value; OnPropertyChanged(); }
        }

        public string ExePath
        {
            get => _exePath;
            set { _exePath = value; OnPropertyChanged(); }
        }

        public ICommand SaveCommand { get; }
        public AddItemWindow DataContext { get; internal set; }

        public AddItemWindow()
        {
            SaveCommand = new RelayCommand(ExecuteSave);
        }

        public Item GetItem()
        {
            return new Item { Name = this.Name, ImagePath = this.ImagePath, ExePath = this.ExePath };
        }

        private void ExecuteSave(object parameter)
        {
            // Here you would normally handle persistence, e.g., saving to a database or file
            MessageBox.Show("Item saved!");
        }

        internal bool ShowDialog()
        {
            throw new NotImplementedException();
        }
    }
}