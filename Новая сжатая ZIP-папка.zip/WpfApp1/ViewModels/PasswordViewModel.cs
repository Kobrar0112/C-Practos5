using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace WpfApp1.ViewModels
{
    public class PasswordViewModel : ViewModelBase
    {
        private string _password;

        public string Password
        {
            get => _password;
            set { _password = value; OnPropertyChanged(); }
        }

        public ICommand SubmitCommand { get; }

        public PasswordViewModel()
        {
            SubmitCommand = new RelayCommand(ExecuteSubmit);
        }

        private void ExecuteSubmit(object parameter)
        {
            if (Password == "expectedPassword")
            {
                MessageBox.Show("Access granted");
                Application.Current.Shutdown();
            }
            else
            {
                MessageBox.Show("Access denied");
            }
        }
    }
}