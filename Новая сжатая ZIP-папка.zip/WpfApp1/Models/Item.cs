using System.Collections.Generic;

namespace WpfApp1.Models
{
    public class Item
    {
        public string Name { get; set; }
        public string ImagePath { get; set; }
        public string ExePath { get; set; }
    }
}